<?php
header("Location:../index.php");

// vim:ts=4:sw=4:
